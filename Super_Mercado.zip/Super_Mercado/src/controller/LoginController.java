package controller;

import javax.swing.JOptionPane;

import Model.Usuario;
import Model.UsuarioDao;
import views.TelaDeCompra;
import views.TelaLogin;

public class LoginController {

    private final TelaLogin view;
    private final UsuarioDao model;
    private final Navegador navegador;
    private final TelaDeCompra telaCompra;

    public LoginController(TelaLogin view, Navegador navegador, UsuarioDao model, TelaDeCompra telaCompra) {
        this.view = view;
        this.navegador = navegador;
        this.model = model;
        this.telaCompra = telaCompra;

        this.view.entrar(e -> entrar());
        this.view.cadastrar(e -> navegador.navegarPara("CADASTRO"));
    }

    private void entrar() {

        String nome = view.getNome();
        String cpf = view.getCpf();

        // ------------------ VALIDAÇÃO SIMPLES ------------------
        if (nome.isEmpty() || cpf.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Preencha todos os campos.", "Atenção",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (cpf.length() != 11) {
            JOptionPane.showMessageDialog(null, "CPF incompleto.", "Erro",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // ------------------ LOGIN REAL ------------------
        Usuario usuario = model.pesquisarUsuario(cpf);

        if (usuario == null) {
            JOptionPane.showMessageDialog(null, "Usuário não encontrado.", "Erro",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // ------------------ DEFINIR TELA ------------------
        if (usuario.isFuncao()) {
            navegador.navegarPara("Tela de Cadastro de Produtos");
        } else {
            telaCompra.setUsuarioLogado(usuario);
            navegador.navegarPara("TELA DE COMPRA");
        }
    }
}
