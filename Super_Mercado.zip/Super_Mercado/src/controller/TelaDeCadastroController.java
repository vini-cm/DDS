package controller;

import javax.swing.JOptionPane;

import Model.Usuario;
import Model.UsuarioDao;
import views.TelaDeCadastro;

public class TelaDeCadastroController {

    private final TelaDeCadastro view;
    private final UsuarioDao model;
    private final Navegador navegador;

    public TelaDeCadastroController(TelaDeCadastro view, UsuarioDao model, Navegador navegador) {
        this.view = view;
        this.model = model;
        this.navegador = navegador;

        // Ações dos botões
        view.cadastrar(e -> cadastrarUsuario());
        view.voltar(e -> navegador.navegarPara("TELA LOGIN"));
    }

    private void cadastrarUsuario() {
        String nome = view.getNome();
        String cpf = view.getCpf();

        // === VALIDAÇÃO DO NOME ===
        if (nome == null || nome.isBlank()) {
            JOptionPane.showMessageDialog(null, "O campo nome não pode estar vazio.", "Erro", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // === VALIDAÇÃO DO CPF (apenas números e tamanho correto) ===
        if (cpf == null || !cpf.matches("\\d{11}")) {
            JOptionPane.showMessageDialog(null, "Digite um CPF válido (apenas 11 números).", "Erro", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // === CPF JÁ EXISTE ===
        if (model.pesquisarUsuario(cpf) != null) {
            JOptionPane.showMessageDialog(null, "Este CPF já está cadastrado.", "Erro", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // === CADASTRAR ===
        Usuario novoUsuario = new Usuario(nome, cpf, false);
        model.adicionarUsuario(novoUsuario);

        JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");
        navegador.navegarPara("TELA LOGIN");
    }
}
