package controller;

import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Model.Produto;
import Model.ProdutoDAO;
import Model.Usuario;
import views.TelaDeCompra;

public class TelaDeCompraController {

    private TelaDeCompra view;
    private DefaultTableModel modeloTabela;
    private DefaultTableModel modeloCarrinho;
    private JLabel lblTotal;
    private double total = 0.0;
    private Usuario usuarioLogado;
    private ProdutoDAO model;
    private Navegador navegador;

    public TelaDeCompraController(
            TelaDeCompra view,
            Navegador navegador,
            Usuario usuarioLogado
    ) {
        this.view = view;
        this.navegador = navegador;
        this.usuarioLogado = usuarioLogado;

        this.modeloTabela = view.getModeloTabela();
        this.modeloCarrinho = view.getModeloCarrinho();
        this.lblTotal = view.getLblTotal();

        this.model = new ProdutoDAO();

        view.voltar(e -> navegador.navegarPara("TELA LOGIN"));
    }

    // ===========================
    // AÇÕES
    // ===========================

    public void atualizarLista() {
        modeloTabela.setRowCount(0);
        List<Produto> produtos = model.listarProdutos();

        for (Produto p : produtos) {
            modeloTabela.addRow(new Object[]{
                    p.getId(), p.getNome(), p.getDescricao(), p.getPreco(), p.getQuantidade()
            });
        }
    }

    public void setUsuario(Usuario usuario) {
        this.usuarioLogado = usuario;
    }

    public void adicionarAoCarrinho(JTable tabelaProdutos) {
        int linha = tabelaProdutos.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(null, "Selecione um produto!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) modeloTabela.getValueAt(linha, 0);
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        double preco = (double) modeloTabela.getValueAt(linha, 3);
        int qtdEstoque = (int) modeloTabela.getValueAt(linha, 4);

        String qtdStr = JOptionPane.showInputDialog("Quantidade desejada:");
        if (qtdStr == null) return;

        int qtd;
        try {
            qtd = Integer.parseInt(qtdStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Digite um número válido!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (qtd <= 0 || qtd > qtdEstoque) {
            JOptionPane.showMessageDialog(null, "Quantidade inválida!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double subtotal = preco * qtd;

        modeloCarrinho.addRow(new Object[]{id, nome, preco, qtd, subtotal});
        total += subtotal;

        atualizarTotal();
    }

    public void removerDoCarrinho(JTable tabelaCarrinho) {
        int linha = tabelaCarrinho.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(null, "Selecione um item!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double subtotal = (double) modeloCarrinho.getValueAt(linha, 4);
        total -= subtotal;

        modeloCarrinho.removeRow(linha);

        atualizarTotal();
    }

    private void atualizarTotal() {
        lblTotal.setText(String.format("Total: R$ %.2f", total));
    }

    public void emitirNotaFiscal() {
        if (modeloCarrinho.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "Carrinho vazio!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        StringBuilder nota = new StringBuilder();
        nota.append("===== NOTA FISCAL =====\n");
        nota.append("Cliente: ").append(usuarioLogado.getNome()).append("\n");
        nota.append("CPF: ").append(usuarioLogado.getCpf()).append("\n\n");
        nota.append("Produtos:\n");

        for (int i = 0; i < modeloCarrinho.getRowCount(); i++) {
            int id = (int) modeloCarrinho.getValueAt(i, 0);
            String nomeProd = (String) modeloCarrinho.getValueAt(i, 1);
            double preco = (double) modeloCarrinho.getValueAt(i, 2);
            int qtd = (int) modeloCarrinho.getValueAt(i, 3);
            double subtotal = (double) modeloCarrinho.getValueAt(i, 4);

            nota.append(String.format("- %s (x%d): R$ %.2f\n", nomeProd, qtd, subtotal));

            Produto p = model.pesquisarProduto(id);
            if (p != null) {
                p.setQuantidade(p.getQuantidade() - qtd);
                model.atualizarProduto(p);
            }
        }

        nota.append("\nTotal pago: R$ ").append(String.format("%.2f", total)).append("\n");
        nota.append("========================");

        JOptionPane.showMessageDialog(null, nota.toString(), "Nota Fiscal", JOptionPane.INFORMATION_MESSAGE);

        // Reset
        modeloCarrinho.setRowCount(0);
        total = 0;
        atualizarTotal();
        atualizarLista();
    }
}
