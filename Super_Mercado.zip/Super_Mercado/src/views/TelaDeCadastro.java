package views;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.text.MaskFormatter;

public class TelaDeCadastro extends JPanel {

    private JTextField textNome;
    private JFormattedTextField textCpf;
    private JButton btnCadastrar;
    private JButton btnVoltar;

    public TelaDeCadastro() {

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitulo = new JLabel("CADASTRO");
        lblTitulo.setFont(new Font("Segoe UI Black", Font.PLAIN, 26));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        add(lblTitulo, c);

        // LABEL NOME
        c.gridy++;
        c.gridwidth = 1;
        add(new JLabel("Nome:"), c);

        // CAMPO NOME
        textNome = new JTextField();
        c.gridx = 1;
        add(textNome, c);

        // LABEL CPF
        c.gridx = 0; c.gridy++;
        add(new JLabel("CPF:"), c);

        // CAMPO CPF FORMATADO
        textCpf = criarCampoCPF();
        c.gridx = 1;
        add(textCpf, c);

        // BOTÃO CADASTRAR
        btnCadastrar = new JButton("Cadastrar");
        c.gridx = 0; c.gridy++; c.gridwidth = 2;
        add(btnCadastrar, c);

        // BOTÃO VOLTAR
        btnVoltar = new JButton("Voltar");
        btnVoltar.setBackground(new Color(255, 200, 200));
        c.gridy++;
        add(btnVoltar, c);
    }

    private JFormattedTextField criarCampoCPF() {
        try {
            MaskFormatter mask = new MaskFormatter("###.###.###-##");
            mask.setPlaceholderCharacter('_');
            return new JFormattedTextField(mask);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao criar máscara CPF");
        }
    }

    public void cadastrar(ActionListener al) {
        btnCadastrar.addActionListener(al);
    }

    public void voltar(ActionListener al) {
        btnVoltar.addActionListener(al);
    }

    public String getNome() {
        return textNome.getText().trim();
    }

    public String getCpf() {
        return textCpf.getText().replace(".", "").replace("-", "");
    }
}
