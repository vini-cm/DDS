package views;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.text.ParseException;

public class TelaLogin extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtNome;
    private JFormattedTextField txtCpf;
    private JButton btnCadastrar, btnLogin;

    public TelaLogin() {

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ---------- LABEL NOME ----------
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(lblNome, gbc);

        // ---------- CAMPO NOME ----------
        gbc.gridx = 1;
        txtNome = new JTextField();
        txtNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
        txtNome.setDocument(soLetras(50));
        add(txtNome, gbc);

        // ---------- LABEL CPF ----------
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(lblCpf, gbc);

        // ---------- CAMPO CPF (MÁSCARA) ----------
        gbc.gridx = 1;
        try {
            MaskFormatter mf = new MaskFormatter("###.###.###-##");
            mf.setPlaceholderCharacter('_');
            txtCpf = new JFormattedTextField(mf);
            txtCpf.setFont(new Font("Tahoma", Font.PLAIN, 20));
        } catch (ParseException e) {
            txtCpf = new JFormattedTextField();
        }
        add(txtCpf, gbc);

        // ---------- BOTÃO ENTRAR ----------
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        btnLogin = new JButton("Entrar");
        btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(btnLogin, gbc);

        // ---------- LABEL INFORMAL ----------
        gbc.gridy = 3;
        JLabel lblNCdt = new JLabel("Não tem cadastro?");
        lblNCdt.setFont(new Font("Tahoma", Font.PLAIN, 18));
        add(lblNCdt, gbc);

        // ---------- BOTÃO CADASTRAR ----------
        gbc.gridy = 4;
        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(btnCadastrar, gbc);
    }

    // ==========================================================
    // INPUT FILTER: SOMENTE LETRAS NO NOME
    // ==========================================================
    private DocumentFilter soLetrasFilter = new DocumentFilter() {
        @Override
        public void insertString(FilterBypass fb, int offset, String text, AttributeSet attr)
                throws BadLocationException {
            if (text.matches("[a-zA-ZÀ-ÿ ]+")) {
                super.insertString(fb, offset, text, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            if (text.matches("[a-zA-ZÀ-ÿ ]+")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    };

    private PlainDocument soLetras(int max) {
        PlainDocument doc = new PlainDocument();
        doc.setDocumentFilter(soLetrasFilter);
        return doc;
    }

    // ==========================================================
    // MÉTODOS PARA O CONTROLLER
    // ==========================================================
    public void entrar(java.awt.event.ActionListener action) {
        btnLogin.addActionListener(action);
    }

    public void cadastrar(java.awt.event.ActionListener action) {
        btnCadastrar.addActionListener(action);
    }

    public String getNome() {
        return txtNome.getText().trim();
    }

    public String getCpf() {
        return txtCpf.getText().replace("_", "").replace(".", "").replace("-", "").trim();
    }
}
